import random


def quicksort(array):
    if len(array) < 2:
        return array
    else:
        pivot = random.sample(range(len(array)), 1)[0]
        lower = []
        higher = []
        for num in array[:pivot] + array[pivot + 1:]:
            if num <= array[pivot]:
                lower.append(num)
            else:
                higher.append(num)

    return quicksort(lower) + [array[pivot]] + quicksort(higher)
