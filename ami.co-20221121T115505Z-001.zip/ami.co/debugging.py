from datetime import datetime
from sys import exit


def getScore():
    while True:
        try:
            score = int(input("(0 strongly disagree, 10 strongly agree): "))
            if score < 0 or score > 10:
                print("Please Enter an integer between 0-10")
            else:
                return score
        except ValueError:
            print("Please Enter an integer between 0-10")


def getUsername(users):
    while True:
        try:
            username = input("Enter username: ").lower()
            if users[username]:
                return username
        except KeyError:
            print("That username is not in our database. Try Again.")


def checkDuplicateUsername(users):
    while True:
        try:
            username = input("Create username: ").lower()
            if users[username]:
                print('That username is already taken. Try another one.')
        except KeyError:
            return username



def getDOB():
    while True:
        try:
            dob = input("Date of Birth (dd/mm/yyyy): ")
            dob = datetime.strptime(dob, '%d/%m/%Y').date()
            today = datetime.today()
            age = today.year - dob.year - ((today.month, today.day) < (dob.month, dob.day))
            if age >=16:
                return dob
            else:
                print('\nDid you type that correctly? You must be at least 16 years old to join ami.co!')
                if checkYesNo("Are you at least 16 years old (y/n)?") == 'n':
                    print("Sorry but you can't create an account. We hope to see you in the future!")
                    exit()
        except ValueError:
            print("Date not in correct format. Try again.")


def checkCountry(question):
    infile = open('countries.txt')
    line = infile.readline()
    countries = []
    while line:
        countries.append(line.strip())
        line = infile.readline()

    while True:
        country = input(question).title().strip()
        if country in countries:
            return country
        else:
            print('That country is not in our database. Are you sure you typed it correctly?\n'
                  'Countries must be typed in English!\n')


def checkLanguage(question):
    infile = open('languages.txt')
    line = infile.readline()
    languages = []
    while line:
        languages.append(line.strip())
        line = infile.readline()

    while True:
        language = input(question).capitalize().strip()
        if language in languages:
            return language
        else:
            print('That language is not in our database. Are you sure you typed it correctly?\n'
                  'Languages must be typed in English!\n')


def getGender():
    while True:
        gender = input('Gender (m,f or other): ').strip().lower()
        if gender in ['m', 'male']:
            return 'Male'
        elif gender in ['f', 'female']:
            return 'Female'
        elif gender == 'other':
            return input('Specify: ')
        else:
            print('Invalid Input. Try again.')


def action():
    while True:
        action = input("\nMain Menu\n1. Find Friends\n2. Add Interests\n"
                       "3. View Profile\n4. Edit Bio\n5. View the Friends you have added\n"
                       "6. View people that have added you as a Friend\n7. Log Out\n"
                       "Enter an option (1-7): ").strip()
        if action in ['1', '2', '3', '4','5','6','7']:
            return action
        else:
            print('\nInvalid Action.')


def addInterest():
    while True:
        action = input("\nWhat interest do you want to add (add 1 at a time)?\n1. Sport.\n"
                       "2. Religion.\n3. Music.\n"
                       "4. Hobby\n5. Food.\n6. Finish\n"
                       "Enter an option (1-6): ").strip()
        if action in ['1', '2', '3', '4', '5', '6']:
            return action
        else:
            print('Invalid input.')


def checkYesNo(question):
    while True:
        ans = input(question).lower().strip()
        if ans not in ['y', 'n','yes','no']:
            print("Please Enter y or n")
        else:
            if ans in ['y','yes']:
                return 'y'
            elif ans in ['n','no']:
                return 'n'


def filterOption():
    while True:
        try:
            option = int(input("\nFilter Options:\n1. Age Range\n2. Nationality\n3. Preferred Language\n"
                               "4. Sports\n5. Religion\n6. Music\n7. Hobby\n8. Food\n"
                               "9. Finish\nEnter an option (1-9): ").strip())
            if option < 1 or option > 9:
                print("Invalid Option")
            else:
                return option
        except ValueError:
            print("Invalid Option")


def ageRange():
    while True:
        try:
            range = input("Age range (eg. 19-21): ").strip()
            range = [value.strip() for value in range.split('-')]
            start = int(range[0])
            end = int(range[1])

            if (end >= start):
                return (start, end)
            else:
                print('Invalid Format')
        except ValueError:
            print('Invalid Format')


def filter():
    filter = {"Age Range": None, "Nationality": [], "Preferred Language": [],
              "Sports": [], "Religion": [], "Music": [], "Hobby": [], "Food": []}

    print("\nNOTE: If you add more than one filter to a category it will find people that have either of the options\n")
    while True:
        option = filterOption()
        if option == 1:
            filter['Age Range'] = ageRange()
        elif option == 2:
            while True:
                filter['Nationality'].append(checkCountry('Country: '))
                add = checkYesNo('Do you want to add another Country (y/n)?')
                if add in 'n':
                    break
        elif option == 3:
            while True:
                filter['Preferred Language'].append(checkLanguage('Preferred Language: '))
                add = checkYesNo('Do you want to add another Language (y/n)?')
                if add == 'n':
                    break
        elif option == 4:
            while True:
                filter['Sports'].append(input('Sports: '))
                add = checkYesNo('Do you want to add another Sport (y/n)?')
                if add == 'n':
                    break
        elif option == 5:
            while True:
                filter['Religion'].append(input('Religion: '))
                add = checkYesNo('Do you want to add another Religion (y/n)?')
                if add == 'n':
                    break
        elif option == 6:
            while True:
                filter['Music'].append(input('Music: '))
                add = checkYesNo('Do you want to add another Music taste (y/n)?')
                if add == 'n':
                    break
        elif option == 7:
            while True:
                filter['Hobby'].append(input('Hobby: '))
                add = checkYesNo('Do you want to add another Hobby (y/n)?')
                if add == 'n':
                    break
        elif option == 8:
            while True:
                filter['Food'].append(input('Food: '))
                add = checkYesNo('Do you want to add another Food taste (y/n)?')
                if add == 'n':
                    break
        elif option == 9:
            return filter


def addFriend(friendsList, newFriend):
    while True:
        option = input('\n1. Add Friend\n2. See next person\nEnter an option (1-2): ')
        if option == '1':
            if newFriend not in friendsList:
                print('\nFriend Added!')
                input("\nSee next person <<Enter>>  ")
                return True
            else:
                print('This person is already in your friends!')
                input("\nSee next person <<Enter>>  ")
                return False

        elif option == '2':
            return False
        else:
            print("Invalid Option.")



