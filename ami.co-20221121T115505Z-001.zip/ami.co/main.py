import user as u
import debugging as dbg

def main():
    users = u.getUsers()
    existingAccount = dbg.checkYesNo("Do you already have an account (y/n)? ")
    if existingAccount == 'y':
        username = dbg.getUsername(users)
        user = users[username]
    else:
        username = dbg.checkDuplicateUsername(users)
        user = u.User()
        user.getUserInfo()
        user.getInterests()
        users[username] = user

    while True:
        action = dbg.action()
        print('')
        if action == '1':
            filter = dbg.checkYesNo("Do you want to add filters to find a match (y/n)? ")
            user.getMatch(users, username, filter)
        elif action == '2':
            user.addInterests()
        elif action == '3':
            print('\nYour Profile:')
            user.printProfile()
            input('\nReturn to Menu <<Enter>> ')
        elif action == '4':
            user.updateBio()
        elif action == '5':
            user.printFriends(users)
        elif action == '6':
            user.printBefriended(users, username)
        elif action == '7':
            u.saveChanges(users)
            break



main()