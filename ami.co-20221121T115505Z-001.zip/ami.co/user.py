import debugging as dbg
from datetime import datetime
import numpy as np
from quicksort import quicksort


class User():

    def __init__(self):
        self.name = None
        self.surname = None
        self.nationality = None
        self.preferredLanguage = None
        self.gender = None
        self.dob = None
        self.interests = []
        self.additionalInterests = {"Sports": [],
                                    "Religion": None,
                                    "Music": [],
                                    "Hobby": [],
                                    "Food": []
                                    }
        self.bio = None
        self.friends = []

    def getUserInfo(self):
        infoInput = ["Name: ", "Surname: ", "Nationality", "Preferred Language", "Gender", "DOB", 'Bio: ']
        personalInfo = []
        print('Enter all your personal information\n')
        for info in infoInput:
            if info == 'DOB':
                personalInfo.append(dbg.getDOB())
            elif info == 'Gender':
                personalInfo.append(dbg.getGender())
            elif info == 'Nationality':
                personalInfo.append(dbg.checkCountry('Country: '))
            elif info == "Preferred Language":
                personalInfo.append(dbg.checkLanguage('Preferred Language: '))
            else:
                personalInfo.append(input(info))

        self.name = personalInfo[0]
        self.surname = personalInfo[1]
        self.nationality = personalInfo[2]
        self.preferredLanguage = personalInfo[3]
        self.gender = personalInfo[4]
        self.dob = personalInfo[5]
        self.bio = personalInfo[6]

        return

    def getMatch(self, users, username, filterYesNo):
        userInterests = np.array(self.interests)

        interestsSimilarity = []
        if filterYesNo == 'y':
            filter = dbg.filter()
            for key, value in users.items():
                if key != username and value.passesFilter(filter):
                    vector = np.array(value.interests) - userInterests
                    euclideanDistance = np.linalg.norm(vector)
                    interestsSimilarity.append((euclideanDistance, key))
        else:
            for key, value in users.items():
                if key != username:
                    vector = np.array(value.interests) - userInterests
                    euclideanDistance = np.linalg.norm(vector)
                    interestsSimilarity.append((euclideanDistance, key))

        if interestsSimilarity:
            sortedSimilarity = quicksort(interestsSimilarity)
            topMatches = sortedSimilarity[:5]
            print('\n\nHere are your matches:')
            for match in topMatches:
                print('')
                users[match[1]].printProfile()
                if dbg.addFriend(self.friends, match[1]):
                    self.friends.append(match[1])

            input('\nYou have seen all your matches.\nReturn to Menu <<Enter>> ')
        else:
            input('\nThere were no results to your search. Try removing some filters.\nReturn to Menu <<Enter>> ')

    def getInterests(self):
        file = open('interests.txt', 'r')

        line = file.readline()
        print("\nTo be able to match you with other users please answers the questions below.\n"
              "Answer on a scale from 0-10 depending on how much you agree with each of the statements\n")
        interests = []
        while line:
            interests.append(line.rstrip())
            line = file.readline()

        for interest in interests:
            print('')
            print(interest)
            self.interests.append(dbg.getScore())

    def printProfile(self):
        print('Name: ', self.name, self.surname)
        print('Nationality: ', self.nationality)
        print('Preferred Language: ', self.preferredLanguage)
        print('Gender: ', self.gender)
        print('Age: ', self.getAge())
        self.printInterests()
        print('Bio: ', self.bio)

    def printInterests(self):
        for key, value in self.additionalInterests.items():
            if value:
                if key != 'Religion':
                    print(key + ':', ', '.join(value))
                else:
                    print(key + ':', value)

    def addInterests(self):
        while True:
            add = dbg.addInterest()
            if add == '1':
                self.additionalInterests['Sports'].append(input('Sport: '))
            elif add == '2':
                self.additionalInterests['Religion'] = input('Religion: ')
            elif add == '3':
                self.additionalInterests['Music'].append(input('Music Taste: '))
            elif add == '4':
                self.additionalInterests['Hobby'].append(input('Hobby: '))
            elif add == '5':
                self.additionalInterests['Food'].append(input('Food: '))
            elif add == '6':
                return

    def passesFilter(self, filter):
        filterTracker = []
        age = filter['Age Range']
        nationality = filter['Nationality']
        language = filter['Preferred Language']
        sports = filter['Sports']
        religion = filter['Religion']
        music = filter['Music']
        hobby = filter['Hobby']
        food = filter['Food']
        if age:
            if self.getAge() >= age[0] and self.getAge() <= age[1]:
                filterTracker.append(True)
            else:
                filterTracker.append(False)
        if nationality:
            filterTracker.append(any([value == self.nationality for value in nationality]))
        if language:
            filterTracker.append(any([value == self.preferredLanguage for value in language]))
        if sports:
            filterTracker.append(any([value in self.additionalInterests['Sports'] for value in sports]))
        if religion:
            filterTracker.append(any([value == self.additionalInterests['Religion'] for value in religion]))
        if music:
            filterTracker.append(any([value in self.additionalInterests['Music'] for value in music]))
        if hobby:
            filterTracker.append(any([value in self.additionalInterests['Hobby'] for value in hobby]))
        if food:
            filterTracker.append(any([value in self.additionalInterests['Food'] for value in food]))

        return all(filterTracker)

    def updateBio(self):
        print('Current Bio: ', self.bio, '\n')
        self.bio = input("Update Bio: ")

    def printFriends(self, users):
        if self.friends:
            print('Friends List:')
            for friend in self.friends:
                print('')
                users[friend].printProfile()
            input('\nReturn to Menu <<Enter>>  ')
        else:
            print("\nYou haven't added any friends. Go to the 'Find Friends' option in the Menu to add some friends.\n"
                  "You can also check if someone has added you as a friend so you can add them as well!")
            input('Return to Menu <<Enter>>  ')

    def printBefriended(self, users, username):
        befriended = []
        for key, value in users.items():
            if username in value.friends:
                befriended.append(key)
        if befriended:
            print('These people have added you as friend:')
            for friend in befriended:
                print('')
                users[friend].printProfile()
                if dbg.addFriend(self.friends, friend):
                    self.friends.append(friend)

            input('\nYou have seen all the people who have added you as friends.\nReturn to Menu <<Enter>> ')
        else:
            input('No one has added you as a friend yet.\nReturn to Menu <<Enter>> ')

    def getAge(self):
        today = datetime.today()
        age = today.year - self.dob.year - ((today.month, today.day) < (self.dob.month, self.dob.day))
        return age


# The functions below are to create the users from the users.txt file (our user database)

def createUser(name, surname, nationality, preferredLanguage, gender, dob, interests, additionalInterests, bio,
               friends):
    u = User()
    u.name = name
    u.surname = surname
    u.nationality = nationality
    u.preferredLanguage = preferredLanguage
    u.gender = gender
    u.dob = dob
    u.interests = interests
    u.additionalInterests['Sports'].extend(additionalInterests["Sports"])
    u.additionalInterests['Music'].extend(additionalInterests["Music"])
    u.additionalInterests['Hobby'].extend(additionalInterests["Hobby"])
    u.additionalInterests['Food'].extend(additionalInterests["Food"])
    u.additionalInterests['Religion'] = additionalInterests['Religion']
    u.bio = bio.strip()
    u.friends.extend(friends)

    return u


def getUsersData(user):
    data = []
    for i in range(11):
        if i < 6 or i == 9:
            data.append(user[i])
        elif i == 6:
            data.append(datetime.strptime(user[i], '%Y-%m-%d').date())
        else:
            data.append(eval(user[i]))

    return data


def getUsers():
    file = open('users.txt', 'r')

    line = file.readline()
    users = []
    while line:
        user = line.split(';')
        users.append(user)
        line = file.readline()

    users = [getUsersData(user) for user in users]
    users = {user[0]: createUser(*user[1:]) for user in users}

    return users


def saveChanges(users):
    outfile = open('users.txt', "w")
    for key, value in users.items():
        print(key + ';' +
              value.name + ';' +
              value.surname + ';' +
              value.nationality + ';' +
              value.preferredLanguage + ';' +
              value.gender + ';' +
              str(value.dob) + ';' +
              str(value.interests) + ';' +
              str(value.additionalInterests) + ';' +
              value.bio + ';' +
              str(value.friends), file=outfile)

    outfile.close()
